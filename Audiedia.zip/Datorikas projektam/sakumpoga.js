document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton69');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'AudipedijaSakumlapa.html';
    });
});