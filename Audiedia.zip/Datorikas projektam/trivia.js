document.addEventListener('DOMContentLoaded', function() {
    // Get the button element by its ID
    const alertButton = document.getElementById('Atbilde');

    alertButton.addEventListener('click', function() {
        alert('Jūsu atbilde ir nepareiza! Pareizā atbilde: Nē, Audi 150 neeksistē.');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Get the button element by its ID
    const alertButton = document.getElementById('Atbilde2');

    // Add a click event listener to the button
    alertButton.addEventListener('click', function() {
        // Display an alert when the button is clicked
        alert('Jūsu atbilde ir pareiza!');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Get the button element by its ID
    const alertButton = document.getElementById('Atbilde3');

    // Add a click event listener to the button
    alertButton.addEventListener('click', function() {
        // Display an alert when the button is clicked
        alert('Jūsu atbilde ir pareiza!');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Get the button element by its ID
    const alertButton = document.getElementById('Atbilde4');

    // Add a click event listener to the button
    alertButton.addEventListener('click', function() {
        // Display an alert when the button is clicked
        alert('Jūsu atbilde ir nepareiza! Pareizā atbilde ir Audi A6.');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Get the button element by its ID
    const alertButton = document.getElementById('Atbilde5');

    // Add a click event listener to the button
    alertButton.addEventListener('click', function() {
        // Display an alert when the button is clicked
        alert('Jūsu atbilde ir pareiza!');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Get the button element by its ID
    const alertButton = document.getElementById('Atbilde6');

    // Add a click event listener to the button
    alertButton.addEventListener('click', function() {
        // Display an alert when the button is clicked
        alert('Jūsu atbilde ir nepareiza! Pareizā atbilde: Vācijā.');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Get the button element by its ID
    const alertButton = document.getElementById('Atbilde7');

    // Add a click event listener to the button
    alertButton.addEventListener('click', function() {
        // Display an alert when the button is clicked
        alert('Jūsu atbilde ir pareiza!');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Get the button element by its ID
    const alertButton = document.getElementById('Atbilde8');

    // Add a click event listener to the button
    alertButton.addEventListener('click', function() {
        // Display an alert when the button is clicked
        alert('Jūsu atbilde ir nepareiza! Pareizā atbilde ir Audi 100.');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Get the button element by its ID
    const alertButton = document.getElementById('Atbilde9');

    // Add a click event listener to the button
    alertButton.addEventListener('click', function() {
        // Display an alert when the button is clicked
        alert('Jūsu atbilde ir nepareiza! Pareizā atbilde ir Nē.');
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Get the button element by its ID
    const alertButton = document.getElementById('Atbilde10');

    // Add a click event listener to the button
    alertButton.addEventListener('click', function() {
        // Display an alert when the button is clicked
        alert('Jūsu atbilde ir pareiza!');
    });
});