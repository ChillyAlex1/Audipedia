document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'AudiA1.html';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton2');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'AudiA2.html';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton3');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'AudiA3.html';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton4');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'AudiA4.html';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton5');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'AudiA5.html';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton6');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'AudiA6.html';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton7');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'AudiA7.html';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton8');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'AudiA8.html';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton9');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'Audi80.html';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    
    const redirectButton = document.getElementById('redirectButton10');

    redirectButton.addEventListener('click', function() {
    
        window.location.href = 'Audi100.html';
    });
});